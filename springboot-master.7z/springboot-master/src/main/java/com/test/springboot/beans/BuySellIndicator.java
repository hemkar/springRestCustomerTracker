package com.test.springboot.beans;

public enum BuySellIndicator {
    B, S;
}